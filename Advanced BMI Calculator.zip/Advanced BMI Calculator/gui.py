import tkinter as tk
from tkinter import ttk, messagebox
import calculator
import database

# Fix blurry text and inputs on high-DPI Windows displays
try:
    from ctypes import windll
    windll.shcore.SetProcessDpiAwareness(1)
except Exception:
    pass

class BMIApp:
    def __init__(self, root):
        self.root = root
        self.root.title("BMI Health Tracker")
        # Allow the window to auto-size itself based on contents and DPI scaling
        self.root.resizable(True, True)
        
        # Apply a clean, modern baseline color
        self.bg_color = "#F4F6F9"
        self.root.configure(bg=self.bg_color)
        
        if not database.initialize_db():
            messagebox.showerror("Database Error", "Failed to initialize the local database. History saving will not work.")
        
        # Professional, slightly muted category colors
        self.category_colors = {
            "Underweight": "#F39C12", # Orange/Yellow
            "Normal": "#27AE60",      # Green
            "Overweight": "#E67E22",  # Carrot Orange
            "Obese": "#C0392B"        # Strong Red
        }
        
        self.setup_styles()
        self.create_widgets()
        
    def setup_styles(self):
        """Configures ttk styles for a professional appearance."""
        style = ttk.Style()
            
        style.configure("TFrame", background=self.bg_color)
        
        # Styling LabelFrames
        style.configure("TLabelframe", background=self.bg_color)
        style.configure("TLabelframe.Label", 
                        font=("Segoe UI", 11, "bold"), 
                        background=self.bg_color, 
                        foreground="#34495E")
                        
        # Styling Labels and Entries - Increased font size for clarity
        style.configure("TLabel", background=self.bg_color, font=("Segoe UI", 12))
        style.configure("TEntry", font=("Segoe UI", 12), padding=4)
        style.configure("TCombobox", font=("Segoe UI", 12), padding=4)
        
        # Styling Buttons (Proper padding and sharper bold text)
        style.configure("TButton", 
                        font=("Segoe UI", 11, "bold"), 
                        padding=8)

    def create_widgets(self):
        """Constructs the UI with clearly separated sections and proper padding."""
        
        # --- HEADER SECTION ---
        # Dark header frame to make the application pop
        header_frame = tk.Frame(self.root, bg="#2C3E50", pady=20)
        header_frame.pack(fill=tk.X)
        
        tk.Label(header_frame, text="BMI Health Tracker", 
                 font=("Segoe UI", 22, "bold"), bg="#2C3E50", fg="white").pack()
        tk.Label(header_frame, text="Monitor your fitness journey", 
                 font=("Segoe UI", 10), bg="#2C3E50", fg="#BDC3C7").pack()
                 
        # --- MAIN CONTAINER ---
        main_frame = ttk.Frame(self.root, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # --- INPUT SECTION ---
        input_frame = ttk.LabelFrame(main_frame, text="User Details", padding=15)
        input_frame.pack(fill=tk.X, pady=(0, 15))
        
        # Grid settings for input alignment
        input_frame.columnconfigure(1, weight=1)
        
        # Added padx for spacing between label and input, increased pady for breathing room
        # Increased Combobox and Entry width and explicitly set the larger font
        ttk.Label(input_frame, text="User Name:").grid(row=0, column=0, sticky=tk.W, pady=12, padx=(0, 10))
        self.name_combobox = ttk.Combobox(input_frame, width=26, font=("Segoe UI", 12))
        users = database.get_unique_users()
        self.name_combobox['values'] = users if users is not None else []
        self.name_combobox.grid(row=0, column=1, sticky=tk.E, pady=12)
        
        ttk.Label(input_frame, text="Weight (kg):").grid(row=1, column=0, sticky=tk.W, pady=12, padx=(0, 10))
        self.weight_entry = ttk.Entry(input_frame, width=26, font=("Segoe UI", 12))
        self.weight_entry.grid(row=1, column=1, sticky=tk.E, pady=12)
        
        ttk.Label(input_frame, text="Height (m):").grid(row=2, column=0, sticky=tk.W, pady=12, padx=(0, 10))
        self.height_entry = ttk.Entry(input_frame, width=26, font=("Segoe UI", 12))
        self.height_entry.grid(row=2, column=1, sticky=tk.E, pady=12)
        
        # --- ACTION BUTTONS SECTION ---
        btn_frame = ttk.Frame(main_frame)
        btn_frame.pack(fill=tk.X, pady=(0, 15))
        
        # Give columns equal weight so buttons expand uniformly
        btn_frame.columnconfigure(0, weight=1)
        btn_frame.columnconfigure(1, weight=1)
        
        calc_btn = ttk.Button(btn_frame, text="Calculate BMI", command=self.handle_calculation)
        clear_btn = ttk.Button(btn_frame, text="Clear Fields", command=self.clear_fields)
        history_btn = ttk.Button(btn_frame, text="View History", command=self.view_history)
        trend_btn = ttk.Button(btn_frame, text="Show BMI Trend", command=self.show_trend)
        
        calc_btn.grid(row=0, column=0, padx=5, pady=5, sticky=tk.EW)
        clear_btn.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        history_btn.grid(row=1, column=0, padx=5, pady=5, sticky=tk.EW)
        trend_btn.grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)
        
        # --- RESULTS SECTION ---
        self.result_frame = ttk.LabelFrame(main_frame, text="Your Result", padding=15)
        self.result_frame.pack(fill=tk.BOTH, expand=True)
        
        # Static label requested by user
        tk.Label(self.result_frame, text="YOUR BMI", font=("Segoe UI", 12, "bold"), bg=self.bg_color, fg="#34495E").pack(pady=(5, 0))
        
        self.bmi_value_lbl = tk.Label(self.result_frame, text="--", 
                                      font=("Segoe UI", 36, "bold"), bg=self.bg_color, fg="#7F8C8D")
        self.bmi_value_lbl.pack(pady=(0, 0))
        
        self.bmi_cat_lbl = tk.Label(self.result_frame, text="AWAITING INPUT", 
                                    font=("Segoe UI", 16, "bold"), bg=self.bg_color, fg="#7F8C8D")
        self.bmi_cat_lbl.pack(pady=(5, 10))

    def validate_inputs(self, name: str, weight_str: str, height_str: str):
        """Validates all user inputs strictly. Returns (is_valid, result)."""
        if not name:
            return False, "Please enter your name."
        if not weight_str:
            return False, "Please enter your weight."
        if not height_str:
            return False, "Please enter your height."
            
        try:
            weight = float(weight_str)
            if weight <= 0:
                return False, "Weight must be greater than zero."
        except ValueError:
            return False, "Weight must be a valid number."
            
        try:
            height = float(height_str)
            if height <= 0:
                return False, "Height must be greater than zero."
        except ValueError:
            return False, "Height must be a valid number."
            
        return True, (weight, height)

    def handle_calculation(self):
        """Handles the calculation event with strict validation."""
        name = self.name_combobox.get().strip()
        weight_str = self.weight_entry.get().strip()
        height_str = self.height_entry.get().strip()
        
        is_valid, validation_result = self.validate_inputs(name, weight_str, height_str)
        
        if not is_valid:
            messagebox.showerror("Input Error", validation_result)
            return
            
        weight, height = validation_result
            
        try:
            bmi = calculator.calculate_bmi(weight, height)
            category = calculator.classify_bmi(bmi)
            
            # --- UPDATE GUI VISUALLY ---
            self.bmi_value_lbl.config(text=f"{bmi:.2f}", fg="#2C3E50")
            color = self.category_colors.get(category, "black")
            self.bmi_cat_lbl.config(text=category.upper(), fg=color)
            
            # Force Tkinter to immediately render the new numbers on screen
            self.root.update_idletasks()
            
            # Save to Database
            success = database.insert_record(name, weight, height, bmi, category)
            if not success:
                messagebox.showerror("Database Error", "Failed to save the record to the database. Please try again.")
            else:
                users = database.get_unique_users()
                self.name_combobox['values'] = users if users is not None else []
                # Show the optional success message after rendering the result
                messagebox.showinfo("Success", "Your BMI has been calculated and saved successfully.")
                
        except ValueError as e:
            messagebox.showerror("Calculation Error", str(e))

    def clear_fields(self):
        """Resets the input fields and cleanly resets the results display."""
        self.name_combobox.set("")
        self.weight_entry.delete(0, tk.END)
        self.height_entry.delete(0, tk.END)
        
        self.bmi_value_lbl.config(text="--", fg="#7F8C8D")
        self.bmi_cat_lbl.config(text="AWAITING INPUT", fg="#7F8C8D")
        
        # Put the cursor back into the user name field
        self.name_combobox.focus()
        
    def view_history(self):
        """Opens the modular History Window to display records."""
        from history_window import HistoryWindow
        HistoryWindow(self.root)
            
    def show_trend(self):
        """Displays the BMI trend graph for the selected user."""
        name = self.name_combobox.get().strip()
        
        if not name:
            messagebox.showwarning("Input Error", "Please select or type a User Name to view their trend.")
            return
            
        import visualization
        success, message = visualization.plot_bmi_trend(name)
        
        if not success:
            messagebox.showinfo("No Data", message)
