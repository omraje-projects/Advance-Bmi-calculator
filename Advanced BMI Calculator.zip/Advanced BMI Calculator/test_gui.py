import tkinter as tk
from tkinter import ttk

root = tk.Tk()
root.geometry("400x200")
style = ttk.Style()
if 'clam' in style.theme_names():
    style.theme_use('clam')

bg_color = "#F4F6F9"
style.configure("TLabelframe", background=bg_color)
style.configure("TLabelframe.Label", background=bg_color, foreground="#34495E")

main_frame = ttk.Frame(root, padding=20)
main_frame.pack(fill=tk.BOTH, expand=True)

result_frame = ttk.LabelFrame(main_frame, text="Your Result", padding=15)
result_frame.pack(fill=tk.BOTH, expand=True)

tk.Label(result_frame, text="YOUR BMI", font=("Segoe UI", 12, "bold"), bg=bg_color, fg="#34495E").pack(pady=(5, 0))

root.update()
# I can't visually see the screen, but I know the structure.
