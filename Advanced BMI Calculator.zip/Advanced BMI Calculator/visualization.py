import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
import database

def plot_bmi_trend(user_name: str):
    """
    Fetches historical BMI data for a specific user and generates a Matplotlib 
    line chart showing their BMI trend over time.
    """
    # 1. Fetch records
    records = database.get_records_by_user(user_name)
    
    # 2. Check for database read errors (returned as None)
    if records is None:
        return False, "Database error occurred while fetching records. Please try again."
        
    # 3. Check for empty history (returned as empty list [])
    if not records:
        return False, f"No records found for user: '{user_name}'.\nPlease calculate and save a BMI first."
        
    dates = []
    bmis = []
    
    # 4. Parse data
    for r in records:
        try:
            date_obj = datetime.strptime(r[6], "%Y-%m-%d %H:%M:%S")
            dates.append(date_obj)
            bmis.append(r[4])
        except ValueError:
            # specifically catch string parsing failures rather than a broad Exception
            continue
            
    if not dates:
        return False, "Failed to parse dates for this user's records."
        
    # 5. Create the Matplotlib Line Chart
    try:
        plt.figure(figsize=(9, 6)) 
        plt.plot(dates, bmis, marker='o', linestyle='-', color='#2196F3', linewidth=2, markersize=6, label="User BMI")
        
        plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
        plt.gca().xaxis.set_major_locator(mdates.AutoDateLocator())
        plt.gcf().autofmt_xdate() 
        
        plt.axhline(y=18.5, color='#FFC107', linestyle='--', linewidth=1.5, label='Underweight Boundary (18.5)')
        plt.axhline(y=25.0, color='#FF9800', linestyle='--', linewidth=1.5, label='Overweight Boundary (25.0)')
        plt.axhline(y=30.0, color='#F44336', linestyle='--', linewidth=1.5, label='Obese Boundary (30.0)')
        
        plt.title(f"BMI Trend - {user_name}", fontsize=14, fontweight='bold', pad=15)
        plt.xlabel("Date", fontsize=12, fontweight='bold')
        plt.ylabel("BMI", fontsize=12, fontweight='bold')
        plt.grid(True, linestyle=':', alpha=0.7)
        plt.legend(loc='upper left', bbox_to_anchor=(1, 1))
        
        plt.tight_layout()
        plt.show() 
        return True, "Success"
        
    except Exception as e:
        # Catch UI/graphics errors gracefully (e.g. TclError from closing the window too fast)
        return False, f"A graphical error occurred while generating the chart:\n{e}"
