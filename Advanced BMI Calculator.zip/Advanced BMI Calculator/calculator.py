"""
BMI Calculator Module

This module provides independent functions to calculate and classify 
Body Mass Index (BMI). It is kept strictly separate from the GUI to ensure 
reusability, modularity, and easy testing.
"""

def calculate_bmi(weight: float, height: float) -> float:
    """
    Calculates the Body Mass Index (BMI).
    
    Formula: BMI = weight / (height ** 2)

    Args:
        weight (float): The weight of the user in kilograms (kg).
        height (float): The height of the user in meters (m).

    Returns:
        float: The calculated raw BMI value.

    Raises:
        ValueError: If weight or height are zero or negative.
    """
    if weight <= 0 or height <= 0:
        raise ValueError("Weight and height must be positive, non-zero numbers.")
    
    # We return the unrounded raw float value here. 
    # Rounding to 2 decimal places will be handled by the GUI layer for display purposes.
    return weight / (height ** 2)


def classify_bmi(bmi: float) -> str:
    """
    Classifies the BMI into a standard health category based on WHO guidelines.

    Args:
        bmi (float): The calculated BMI value.

    Returns:
        str: The BMI category (Underweight, Normal, Overweight, Obese).
        
    Raises:
        ValueError: If BMI is zero or negative.
    """
    if bmi <= 0:
        raise ValueError("BMI must be a positive number.")
        
    if bmi < 18.5:
        return "Underweight"
    elif 18.5 <= bmi < 25:
        return "Normal"
    elif 25 <= bmi < 30:
        return "Overweight"
    else:  # BMI >= 30
        return "Obese"
