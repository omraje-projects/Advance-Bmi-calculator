# Advanced BMI Calculator

## 1. Project Title
**Advanced BMI Calculator - Internship Task 2**

## 2. Project Description
The Advanced BMI Calculator is a fully-featured, desktop-based Graphical User Interface (GUI) application. It allows users to calculate their Body Mass Index (BMI), automatically classifies their health category, and saves their data to a local database. It also provides advanced features such as viewing historical records in a table and generating visual trend graphs over time.

## 3. Objective
This project was built to fulfill the requirements for Internship Task 2. The primary objective is to demonstrate proficiency in Python programming by combining front-end UI development, back-end mathematical logic, persistent database management, and data visualization into a single, cohesive application.

## 4. Features
* **User Profiles:** Automatically tracks unique users by name.
* **Instant Calculation:** Computes BMI with high accuracy.
* **Smart Categorization:** Provides dynamic, color-coded health classifications.
* **Persistent Storage:** Saves all calculations automatically to a local database.
* **History Table:** View past records in a clean, scrollable, and filterable window.
* **Visual Analytics:** Generates interactive line charts to track BMI progress over time.
* **Robust UI:** Clean, modern, and professional desktop layout.

## 5. Technologies Used
* **Python 3:** Core programming language.
* **Tkinter & ttk:** Built-in Python library used for building the Graphical User Interface (GUI).
* **SQLite3:** Built-in Python library used as a lightweight, persistent relational database.
* **Matplotlib:** External Python library used for plotting the BMI trend graphs.

## 6. Project Structure
The application is built using a highly modular architecture:
* `main.py` - The entry point that initializes and launches the application.
* `gui.py` - Handles the Tkinter main window layout, buttons, inputs, and validation.
* `calculator.py` - Independent module containing pure math and classification logic.
* `database.py` - Manages all SQLite3 queries, connections, and table creation.
* `history_window.py` - A dedicated module for the `ttk.Treeview` history table and filtering.
* `visualization.py` - Handles fetching data and rendering the Matplotlib chart.
* `requirements.txt` - Lists the external libraries required to run the app.
* `bmi_database.db` - The SQLite database file (generated automatically upon first run).

## 7. BMI Formula
The application calculates BMI using the standard World Health Organization (WHO) formula:
**BMI = Weight (kg) / [Height (m)]²**

## 8. BMI Classification
Results are classified into four strict categories:
* **Underweight:** BMI < 18.5
* **Normal:** 18.5 ≤ BMI < 25.0
* **Overweight:** 25.0 ≤ BMI < 30.0
* **Obese:** BMI ≥ 30.0

## 9. Database Structure
Data is stored securely in an SQLite table named `bmi_records` with the following schema:
* `id` (INTEGER PRIMARY KEY AUTOINCREMENT)
* `user_name` (TEXT NOT NULL)
* `weight` (REAL NOT NULL)
* `height` (REAL NOT NULL)
* `bmi` (REAL NOT NULL)
* `category` (TEXT NOT NULL)
* `recorded_at` (TEXT NOT NULL)

## 10. How the Application Works
1. The user inputs their Name, Weight, and Height.
2. The GUI validates the inputs (ensuring they are numbers and greater than zero).
3. The inputs are passed to the Calculator module to determine the BMI and Category.
4. The GUI displays the color-coded result.
5. The Database module intercepts the result, generates a timestamp, and saves it to SQLite.
6. The user can then open the History window or Trend Graph, which pulls data directly from SQLite.

## 11. Installation Requirements
* **Python 3.x** must be installed on your system.
* You need to install the required external library (`matplotlib`).

To install dependencies, open your terminal/command prompt and run:
```bash
pip install -r requirements.txt
```

## 12. How to Run the Application
Navigate to the project folder in your terminal and execute the main file:
```bash
python main.py
```

## 13. Example Usage
1. Open the app and type **"John Doe"** in the User Name field.
2. Enter **70** for Weight (kg) and **1.75** for Height (m).
3. Click **"Calculate BMI"**. 
4. The app will display **"BMI: 22.86"** and **"Category: NORMAL"** in green text.
5. Click **"Clear Fields"** to reset the form.
6. Click **"Show BMI Trend"** to see a plotted graph of John Doe's fitness journey!

## 14. Error Handling
The application relies heavily on defensive programming to ensure it never crashes:
* **Empty/Missing Inputs:** Triggers a popup asking the user to fill out the form.
* **Invalid Characters:** If a user types letters (e.g., "Sixty") into a number field, a popup warns them to enter a valid number.
* **Negative/Zero Values:** Blocked instantly to prevent impossible physics or mathematical errors (like Divide by Zero).
* **Database Failures:** If the database file is locked or missing, errors are caught silently, and the user is shown a friendly Tkinter warning instead of a system crash.

## 15. BMI Trend Visualization
By utilizing Matplotlib, the application draws a timeline of a specific user's BMI. 
* The **X-Axis** shows the exact Date and Time.
* The **Y-Axis** shows the BMI score.
* Horizontal, color-coded reference lines (at 18.5, 25, and 30) are drawn across the graph so users can visually see how close they are to the boundaries of Underweight, Normal, and Overweight.

## 16. Future Improvements
While fully functional, future updates to the application could include:
* Support for Imperial units (Pounds and Inches).
* Ability to edit or delete specific historical records.
* Exporting history data to a CSV or Excel file.
* Password protection for individual user profiles.

## 17. Author Section
* **Developed by:** [Your Name Here]
* **Role:** Intern
* **Task:** Task 2 - Advanced BMI Calculator
* **Date:** September 2026
