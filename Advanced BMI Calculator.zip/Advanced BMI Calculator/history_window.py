import tkinter as tk
from tkinter import ttk, messagebox
import database

class HistoryWindow:
    def __init__(self, parent):
        self.window = tk.Toplevel(parent)
        self.window.title("BMI History")
        self.window.geometry("750x450")
        self.window.minsize(700, 400)
        
        # --- Filter Section ---
        filter_frame = tk.Frame(self.window, padx=10, pady=10)
        filter_frame.pack(fill=tk.X)
        
        tk.Label(filter_frame, text="Filter by User:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.user_filter = ttk.Combobox(filter_frame, state="readonly", width=25)
        self.user_filter.pack(side=tk.LEFT, padx=5)
        self.update_user_list()
        
        filter_btn = ttk.Button(filter_frame, text="Filter", command=self.apply_filter)
        filter_btn.pack(side=tk.LEFT, padx=5)
        
        reset_btn = ttk.Button(filter_frame, text="Show All / Refresh", command=self.load_all_records)
        reset_btn.pack(side=tk.LEFT, padx=5)
        
        # --- Message Label ---
        self.msg_label = tk.Label(self.window, text="", fg="red", font=("Arial", 10, "italic"))
        self.msg_label.pack(pady=5)
        
        # --- Treeview Section ---
        tree_frame = tk.Frame(self.window, padx=10, pady=10)
        tree_frame.pack(fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        columns = ("ID", "User Name", "Weight (kg)", "Height (m)", "BMI", "Category", "Date & Time")
        self.tree = ttk.Treeview(tree_frame, columns=columns, show="headings", yscrollcommand=scrollbar.set)
        
        self.tree.heading("ID", text="ID")
        self.tree.column("ID", width=40, anchor=tk.CENTER)
        
        self.tree.heading("User Name", text="User Name")
        self.tree.column("User Name", width=120, anchor=tk.W)
        
        self.tree.heading("Weight (kg)", text="Weight (kg)")
        self.tree.column("Weight (kg)", width=80, anchor=tk.CENTER)
        
        self.tree.heading("Height (m)", text="Height (m)")
        self.tree.column("Height (m)", width=80, anchor=tk.CENTER)
        
        self.tree.heading("BMI", text="BMI")
        self.tree.column("BMI", width=80, anchor=tk.CENTER)
        
        self.tree.heading("Category", text="Category")
        self.tree.column("Category", width=100, anchor=tk.CENTER)
        
        self.tree.heading("Date & Time", text="Date & Time")
        self.tree.column("Date & Time", width=150, anchor=tk.CENTER)
        
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.tree.yview)
        
        self.load_all_records()

    def update_user_list(self):
        """Fetches unique users from the database for the dropdown filter."""
        users = database.get_unique_users()
        if users is None:
            users = []
        self.user_filter['values'] = users

    def populate_tree(self, records):
        """Clears the treeview and inserts new records."""
        for item in self.tree.get_children():
            self.tree.delete(item)
            
        if not records:
            self.msg_label.config(text="No records found.")
            return
            
        self.msg_label.config(text="")
        for r in records:
            rec_id = r[0]
            name = r[1]
            weight = f"{r[2]:.1f}"
            height = f"{r[3]:.2f}"
            bmi = f"{r[4]:.2f}"
            category = r[5]
            date_time = r[6]
            
            self.tree.insert("", tk.END, values=(rec_id, name, weight, height, bmi, category, date_time))

    def load_all_records(self):
        """Loads all records, newest first."""
        self.user_filter.set('')
        
        records = database.get_all_records() 
        
        # Detect Database Read Error (None instead of list)
        if records is None: 
            messagebox.showerror("Database Error", "Failed to retrieve history from the database.")
            records = []
            
        self.populate_tree(records)
        self.update_user_list()

    def apply_filter(self):
        """Loads records for a specific user, ensuring newest records appear first."""
        user = self.user_filter.get().strip()
        if not user:
            self.load_all_records()
            return
            
        records = database.get_records_by_user(user)
        
        if records is None:
            messagebox.showerror("Database Error", f"Failed to retrieve filtered history for '{user}'.")
            records = []
        elif records:
            # reverse the ASC list to show newest first
            records = records[::-1]
            
        self.populate_tree(records)
