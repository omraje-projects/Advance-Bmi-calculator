import sqlite3
from datetime import datetime
import logging

# Setup basic logging to print errors to the console without crashing the app
logging.basicConfig(level=logging.ERROR, format='%(asctime)s - %(levelname)s - %(message)s')

DB_NAME = "bmi_database.db"

def initialize_db() -> bool:
    """
    Initializes the database by creating the bmi_records table if it doesn't exist.
    """
    try:
        with sqlite3.connect(DB_NAME) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS bmi_records (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_name TEXT NOT NULL,
                    weight REAL NOT NULL,
                    height REAL NOT NULL,
                    bmi REAL NOT NULL,
                    category TEXT NOT NULL,
                    recorded_at TEXT NOT NULL
                )
            ''')
            conn.commit()
            return True
    except sqlite3.Error as e:
        logging.error(f"Database initialization error: {e}")
        return False

def insert_record(user_name: str, weight: float, height: float, bmi: float, category: str) -> bool:
    """Inserts a new BMI record into the database."""
    try:
        recorded_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with sqlite3.connect(DB_NAME) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO bmi_records (user_name, weight, height, bmi, category, recorded_at)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (user_name, weight, height, bmi, category, recorded_at))
            conn.commit()
            return True
    except sqlite3.Error as e:
        logging.error(f"Failed to insert record: {e}")
        return False

def get_all_records():
    """Retrieves all BMI records from the database."""
    try:
        with sqlite3.connect(DB_NAME) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM bmi_records ORDER BY recorded_at DESC')
            return cursor.fetchall()
    except sqlite3.Error as e:
        logging.error(f"Failed to fetch all records: {e}")
        # Explicitly return None (instead of []) so the GUI knows an error occurred
        return None

def get_records_by_user(user_name: str):
    """Retrieves all BMI records for a specific user, sorted chronologically."""
    try:
        with sqlite3.connect(DB_NAME) as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM bmi_records 
                WHERE user_name = ? 
                ORDER BY recorded_at ASC
            ''', (user_name,))
            return cursor.fetchall()
    except sqlite3.Error as e:
        logging.error(f"Failed to fetch records for user '{user_name}': {e}")
        return None

def get_unique_users():
    """Retrieves a list of all unique user names currently in the database."""
    try:
        with sqlite3.connect(DB_NAME) as conn:
            cursor = conn.cursor()
            cursor.execute('SELECT DISTINCT user_name FROM bmi_records ORDER BY user_name ASC')
            rows = cursor.fetchall()
            return [row[0] for row in rows]
    except sqlite3.Error as e:
        logging.error(f"Failed to fetch unique users: {e}")
        return None
