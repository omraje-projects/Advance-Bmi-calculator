import tkinter as tk
from gui import BMIApp

def main():
    # Initialize the main Tkinter window
    root = tk.Tk()
    
    # Create the application object
    app = BMIApp(root)
    
    # Start the event loop
    root.mainloop()

if __name__ == "__main__":
    main()
